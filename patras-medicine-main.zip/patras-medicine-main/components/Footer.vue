<template>
  <footer class="footer">
    <div class="container">
      <div class="row footer-details">
        <div class="col-sm-6 logo-footer">
          <img src="https://static.igem.wiki/teams/4118/wiki/logo-patras-med-white.png" height="130" width="105" alt="iGEM University of Patras" />
          <p>
            University of Patras<br>
            26504 Rio, Greece<br><br>
            patrasmedigem@gmail.com
          </p>
        </div>
        <div class="col-sm-6 sponsors">
          <div>
            <a href="https://www.rgcc-group.com"><img class="rgcc" src="https://static.igem.wiki/teams/4118/wiki/website-assets/sponsors/logo-rgcc-white.png" alt="RGCC" /></a>
            <a href="https://eu.idtdna.com/pages"><img class="idt" src="https://static.igem.wiki/teams/4118/wiki/website-assets/sponsors/idt-logo.png" alt="IDT" /></a>
            <a href="https://international.neb.com/about-neb/neb-overview "><img class="neb" src="https://static.igem.wiki/teams/4118/wiki/website-assets/sponsors/neb-logo.png" alt="NEB" /></a>
            <a href="https://www.naco.gr/ "><img class="naco" src="https://static.igem.wiki/teams/4118/wiki/website-assets/sponsors/naco-logo.png" alt="Naco" /></a>
            <a href="https://www.snapgene.com/"><img class="snapgene" src="https://static.igem.wiki/teams/4118/wiki/website-assets/sponsors/snapgene-logo.png" alt="SnapGene" /></a>
            <a href="https://www.upatras.gr/en"><img class="patrasuniversity" src="https://static.igem.wiki/teams/4118/wiki/website-assets/sponsors/patras-university-logo.png" alt="Patras University" /></a>
          </div>
        </div>
      </div>

      <hr>

      <div class="row creds">
        <div class="col-lg-4 socials order-lg-last">
          <div>
            <a href="https://open.spotify.com/show/3uL0UutbwkTXckC3YIxaqv?si=7b80e181b9e3448a" class="ms-3"><img src="https://static.igem.wiki/teams/4118/wiki/icon-spotify.svg" alt="Listen our podcasts" /></a>
            <a href="https://www.facebook.com/igempatras" class="ms-3"><img src="https://static.igem.wiki/teams/4118/wiki/icon-facebook.svg" alt="Follow us on Facebook" /></a>
            <a href="https://www.instagram.com/patras.med/" class="ms-3"><img src="https://static.igem.wiki/teams/4118/wiki/icon-instagram.svg" alt="Follow us on Instagram" /></a>
            <a href="https://twitter.com/IgemMed" class="ms-3"><img src="https://static.igem.wiki/teams/4118/wiki/icon-twitter.svg" alt="Follow us on Twitter" /></a>
            <a href="https://gr.linkedin.com/company/igem-patras-medicine" class="ms-3"><img src="https://static.igem.wiki/teams/4118/wiki/icon-linkedin.svg" alt="Follow us on Linkedin" /></a>
          </div>
        </div>
        <div class="col-lg-8 copy order-lg-first">
          <p class="small">&copy; 2022 - iGEM Patras Medicine.<br>
          Content on this site is licensed under a <a href="https://creativecommons.org/licenses/by/4.0/" rel="license" target="_blank">Creative Commons Attribution 4.0 International license</a>.<br>
          The repository used to create this website is available at <a href="https://gitlab.igem.org/2022/patras-medicine" rel="gitlab" target="_blank">gitlab.igem.org/2022/patras-medicine</a>.</p>
        </div>
      </div>
    </div>
  </footer>
</template>
